import subprocess
import json
import os

def run_cpp_scanner(file_path):
    # Caminho absoluto do scanner.exe
    scanner_path = os.path.join(os.path.dirname(__file__), "..", "scanner", "scanner.exe")
    if not os.path.isfile(scanner_path):
        raise RuntimeError(f"scanner.exe não encontrado em {scanner_path}")
    # Chama scanner.exe e captura a saída
    try:
        result = subprocess.run([scanner_path, file_path], capture_output=True, text=True, timeout=30)
        if result.returncode != 0:
            print("Erro no scanner:", result.stderr)
            return None
        return json.loads(result.stdout)
    except Exception as e:
        print(f"Erro ao executar scanner.exe: {e}")
        return None
